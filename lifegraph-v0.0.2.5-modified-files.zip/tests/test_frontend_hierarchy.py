from pathlib import Path


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_four_level_view_markup_is_present() -> None:
    html = (PROJECT_ROOT / "frontend" / "index.html").read_text(encoding="utf-8")

    for view in ("life", "year", "month", "day"):
        assert f'data-life-view="{view}"' in html

    for element_id in (
        "lifeMapLifeView",
        "lifeMapYearView",
        "lifeMapMonthView",
        "lifeMapDayView",
        "yearGrid",
        "monthGrid",
        "dayGrid",
    ):
        assert f'id="{element_id}"' in html

    assert "星期一" not in html
    assert "不按星期留空" in html


def test_hierarchy_logic_keeps_life_canvas_and_drills_down() -> None:
    javascript = (PROJECT_ROOT / "frontend" / "app.js").read_text(encoding="utf-8")

    assert 'const frontendBuildVersion = "0.0.2.5"' in javascript
    assert 'switchLifeMapView("year")' in javascript
    assert 'switchLifeMapView("month")' in javascript
    assert 'switchLifeMapView("day")' in javascript
    assert 'openDateDrawer(isoDate)' in javascript
    assert 'drawLifeGrid(currentProgress, force)' in javascript
    assert 'label: String(day).padStart(2, "0")' in javascript
